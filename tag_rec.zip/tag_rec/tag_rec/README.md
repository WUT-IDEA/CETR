
Torch  implementation for our Icassp'23 paper:

run_glue_for_tag_rec.py

Dependencies:
argparse, glob, json, logging, os, random, pandas, numpy, torch.

## Citation
Our code is implemented based on the GLUE framework.

